<?php

/**
 * @file
 * Contains database additions for a 1.x site that uses a dash-bearing plugin.
 *
 * Enables the openid_connect_test module (which registers the "acm-idm"
 * test plugin) and adds the 1.x configuration object for that plugin so that
 * openid_connect_update_8200() runs the machine-name sanitization branch.
 */

use Drupal\Core\Database\Database;

$connection = Database::getConnection();

// Load the extensions and enable the openid_connect_test module.
$extensions = $connection->select('config')
  ->fields('config', ['data'])
  ->condition('collection', '')
  ->condition('name', 'core.extension')
  ->execute()
  ->fetchField();
$extensions = unserialize($extensions);
$extensions['module']['openid_connect_test'] = 0;
$connection->update('config')
  ->fields(['data' => serialize($extensions)])
  ->condition('collection', '')
  ->condition('name', 'core.extension')
  ->execute();

// The 1.x configuration object for the dash-bearing plugin. The plugin id
// "acm-idm" cannot be a Drupal config entity machine name, so update 8200
// must sanitize it to "acm_idm" while preserving "acm-idm" as the slug.
$connection->insert('config')
  ->fields([
    'collection',
    'name',
    'data',
  ])
  ->values([
    'collection' => '',
    'name' => 'openid_connect.settings.acm-idm',
    'data' => serialize([
      'enabled' => TRUE,
      'settings' => [
        'client_id' => 'dash_client_id',
        'client_secret' => 'dash_client_secret',
        'authorization_endpoint' => 'https://example.com/oauth2/authorize',
        'token_endpoint' => 'https://example.com/oauth2/token',
        'userinfo_endpoint' => 'https://example.com/oauth2/UserInfo',
      ],
    ]),
  ])
  ->execute();

// A 1.x identity mapping for the dash-bearing plugin. Update 8200 sanitizes the
// client machine name to "acm_idm", so update 8204 has to migrate this mapping
// under the sanitized name as well. Otherwise the runtime provider name built
// from the entity id would never match and this user would be treated as
// somebody who has never logged in before.
$connection->insert('openid_connect_authmap')
  ->fields([
    'aid',
    'uid',
    'client_name',
    'sub',
  ])
  ->values([
    'aid' => '2',
    'uid' => '1',
    'client_name' => 'acm-idm',
    'sub' => 'sub-of-dash-user',
  ])
  ->execute();
